<?php
require_once('admin/includes/configurations.php');
$body_id = 'profilebody';
require_once('logincheck.php');
require_once('admin/module/classStudent.php');
require_once('admin/module/classStudentCourse.php');
require_once('admin/module/classManageClass.php');

$studentProfile = $StudentObj->getStudentById($_SESSION['student_user']['id']);
$StudentCourses = $StudentCourseObj->getStudentClassCourseById($_SESSION['student_user']['id']);

?>
<?php require_once('header.php'); ?>

<div class="slider_section">
  <div class="profile_sec">
    <div class="col-md-12">
      <div class="col-md-5 col-sm-12 col-xs-12 maxwidth">
        <h1 class="profile_heading">My Profile</h1>
        <div class="innerpage-left">
          <div class="profileimg">
            <div class="row">
              <div class="col-md-3 col-sm-3 col-xs-6">
                <?php
                        $defaultImage = "images/default.png";
                        if($studentProfile['profile_pic'] != ""){
                          $defaultImage = PP_UPLOAD_PATH  . $studentProfile['profile_pic'];      
                        }
                      ?>
                <div class="img"><img alt="" src="<?php echo $defaultImage;?>"></div>
              </div>
              <div class="col-md-9 col-sm-9  col-xs-6">
                <div class="profile-detail">
                  <div class="edit_profile"><a href="change-password.php">Change Password</a> &nbsp; <a href="editprofile.php">Edit Profile</a></div>
                  <div class="name"><?php echo $CommanObj->inscrape($studentProfile['fname']);?> <?php echo $CommanObj->inscrape($studentProfile['mname']);?> <?php echo $CommanObj->inscrape($studentProfile['lname']);?></div>
                  <?php /* ?><div class="gender"><?php echo $CommanObj->inscrape($studentProfile['gender']);?></div>
                        <div class="emailaddress"><?php echo $CommanObj->inscrape($studentProfile['email']);?></div><?php */ ?>
                  <div class="date">Class Year: <?php echo $CommanObj->inscrape($studentProfile['class_year']);?></div>
                  <p>Term: <?php echo $CommanObj->inscrape($studentProfile['term']);?></p>
                </div>
              </div>
            </div>
            <div class="viewmatch search_study">
              <div class="row">
                <div class="col-md-3 col-sm-3"><a href="#">Request a study buddy</a> </div>
                <div class="col-md-3 col-sm-3"><a href="search-group.php">Make a friend</a> </div>
                <div class="col-md-3 col-sm-3"><a href="search-group.php">Find a study spot</a> </div>
                <div class="col-md-3 col-sm-3"><a href="#">Request a tutor</a></div>
              </div>
            </div>
            <div class="profile-sec-3">
              <div class="row">
                <?php
                        $CountData = mysql_num_rows($StudentCourses);
                        $ClassOffset = 12 / $CountData; 
                        while($StudentCourseData = mysql_fetch_assoc($StudentCourses)){
                            $className = $ManageClassObj->getManageClassByManageClassID($StudentCourseData['department_id']);
                        ?>
                <div class="col-md-3 col-sm-3"> <a href="#"><?php echo $CommanObj->inscrape($className['name']);?> <?php echo $StudentCourseData['course_num'];?> </a> </div>
                <?php
                        }
                      ?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--<div class="col-md-5 col-sm-12 col-xs-12 pull-right">
              <div class="notification">
                <div class="responsive-table">
                  <table width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tbody>
                      <tr>
                        <td colspan="3" class="greenbg">Notification</td>
                      </tr>
                      <tr>
                        <td width="10%" class="num">1</td>
                        <td width="40%">12 Febuary, 2015</td>
                        <td width="60%">Lorem Ipsum is that it has a more-or-less normal distribution of letters.</td>
                      </tr>
                      <tr>
                        <td class="num">2</td>
                        <td>18 March, 2015</td>
                        <td>Lorem Ipsum is that it has a more-or-less normal distribution,</td>
                      </tr>
                      <tr>
                        <td class="num">3</td>
                        <td>06 June, 2015</td>
                        <td>Lorem Ipsum is that it has a more-or-less normal distribution of letters.</td>
                      </tr>
                      <tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div> -->
    </div>
    <div class="top_four_icons">
      <div class="container">
        <div class="row">
            <div id="spacer">&nbsp;</div>
        </div> 
        <div class="row">
          <div class="col-md-3 col-sm-3"> <a href="#"><img alt="Request a Study Buddy" title="Request a Study Buddy" src="images/request_s_b.png" ></a> </div>
          <div class="col-md-3 col-sm-3"> <a href="#"><img alt="Make a New Friend" title="Make a New Friend" src="images/make_n_f.png" ></a> </div>
          <div class="col-md-3 col-sm-3"> <a href="search-group.php"><img alt="Find a Study Spot" title="Find a Study Spot" src="images/find_s_s.png" ></a> </div>
          <div class="col-md-3 col-sm-3"> <a href="#"><img alt="Request a Tutor" title="Request a Tutor" src="images/request_t.png" ></a> </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--#startstudy-->
<?php require_once('footer.php'); ?>
