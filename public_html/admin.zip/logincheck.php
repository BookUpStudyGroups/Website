<?php
if( !isset($body_id) )
	$body_id = 'body_id';


if( $body_id == 'homebody' ){
  if( isset( $_SESSION['student_user'] ) ){
    header('location: profile.php');
    exit;
  }
      
}//if login or register

  
  //no access after login 
if( $body_id == 'registerbody' || $body_id == 'loginbody' ){
	if( isset( $_SESSION['student_user'] ) ){
		header('location: index.php');
		exit;
	}
  		
}//if login or register
  
  //no access without login
if( $body_id == 'add_group_body' || $body_id == 'search_group_body' || $body_id == 'profilebody' ){
    if( !isset( $_SESSION['student_user'] ) ){
    	header('location: login.php');
    	exit;
    }
    	
}//no access without login

?>
