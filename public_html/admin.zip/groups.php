<?php 
require_once('admin/includes/configurations.php');
$body_id = 'groupbody';
require_once('admin/module/classGroup.php');
require_once('admin/module/classStudent.php');
require_once('admin/module/classManageClass.php');

$user_id = $_SESSION['student_user']['id'];


$sucessMsg = "";
$errorMsg = "";
if(isset($_REQUEST['action']) && $_REQUEST['action'] != ""){
  $user_id = $_SESSION['student_user']['id'];
  $groupId =  $CommanObj->inscrape($_REQUEST['id']);
  $action =  $CommanObj->inscrape($_REQUEST['action']);
  if($action == "left"){
    $StudentObj->leftStudentGroup($CommanObj->inscrape($user_id), $groupId);
    $sucessMsg = "You have been successfully left the group.";
  }else if($action == "delete"){
    $groupDetails = $GroupObj->getGroupById($groupId);
    if(($groupDetails['user_id'] == $user_id)){
      $OtherJoinedObj = $StudentObj->isOtherStudentJointGroup($user_id, $groupId);

      if(mysql_num_rows($OtherJoinedObj) > 0){
        $errorMsg = "You can not delete this group as other user has joined this group.";
      }else{
        $GroupObj->deleteGroupById($groupId);
        $sucessMsg =  "Group has been deleted successfully.";  
      }
      
    }else{
      $errorMsg = "You are not authorize for this.";
    }
  }

}

$objRsCreatedGroup = $GroupObj->getGroupsByUserId($user_id);
$jointGroupObj = $StudentObj->jointGroupDetails($user_id);

require_once('header.php'); 
?>
<div class="white_bg">
	<div class="container">
      <?php
        if($sucessMsg != ""){
      ?>
          <div class="row successmsg">
              <?php echo $sucessMsg;?>
          </div> 
      <?php    
        }
      ?>
      <?php
        if($errorMsg != ""){
      ?>
          <div class="row errormsg">
              <?php echo $errorMsg;?>
          </div> 
      <?php    
        }
      ?>
    	<div class="row">
        <div class="col-md-6 col-sm-6">
        <div class="ms-group groups-css">

        <div class="responsive-table">
                  <table width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tbody>
                      <tr>
                        <td class="greenbg" colspan="3">My Study Groups</td>
                      </tr>
                      <?php 
                        if(mysql_num_rows($objRsCreatedGroup) == 0){
                      ?>    
                          <tr>
                            <td colspan="3" class="no_record">No Group Found.</td>
                          </tr>
                      <?php
                        }
                        while($objGroup = mysql_fetch_assoc($objRsCreatedGroup)){
                            $LoSDataClass = $ManageClassObj->getManageClassByManageClassID($objGroup['class_id']);
                            $OtherJoinedObj = $StudentObj->isOtherStudentJointGroup($user_id, $objGroup['id']);
                      ?>
                        <tr>
                          <td width="70%">
                            <?php echo $CommanObj->inscrape($objGroup['topic_name']);?>
                            <br />
                            <i><?php echo $CommanObj->inscrape($LoSDataClass['name']) . " " . $CommanObj->inscrape($objGroup['class_number']);?></i>
                          </td>
                          <td width="30%">
                            <div class="edit"><a href="editgroup.php?id=<?php echo $objGroup['id']; ?>">Edit</a></div> 
                            <?php 
                              if(mysql_num_rows($OtherJoinedObj) == 0){
                            ?>
                              <div class="delete"><a href="groups.php?action=delete&id=<?php echo $objGroup['id']; ?>">Delete</a></div>
                            <?php }else{
                            ?>  
                              <div class="delete"><a href="groups.php?action=left&id=<?php echo $objGroup['id']; ?>">Leave</a></div>
                            <?php
                            } ?>  
                          </td>
                        </tr>

                      <?php    
                        }
                      ?>

                      <tr>
                    </tr></tbody>
                  </table>
                </div>
        </div>
        </div>
        <div class="col-md-6 col-sm-6">
        <div class="js-group groups-css">
        <div class="responsive-table">
                  <table width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tbody>
                      <tr>
                        <td class="greenbg" colspan="3">joined study groups</td>
                      </tr>
                      <?php 
                        if(mysql_num_rows($jointGroupObj) == 0){
                      ?>    
                          <tr>
                            <td colspan="3" class="no_record">No Group Found.</td>
                          </tr>
                      <?php
                        }
                        while($objGroup = mysql_fetch_assoc($jointGroupObj)){
                            $LoSDataClass = $ManageClassObj->getManageClassByManageClassID($objGroup['class_id']);
                            $OtherJoinedObj = $StudentObj->isOtherStudentJointGroup($user_id, $objGroup['id']);
                      ?>
                        <tr>
                          <td width="70%">
                            <?php echo $CommanObj->inscrape($objGroup['topic_name']);?>
                            <br />
                            <i><?php echo $CommanObj->inscrape($LoSDataClass['name']) . " " . $CommanObj->inscrape($objGroup['class_number']);?></i>
                          </td>
                          <td width="30%" align="right">
                            <div class="delete"><a href="groups.php?action=left&id=<?php echo $objGroup['id']; ?>">Leave</a></div>
                          </td>
                        </tr>

                      <?php    
                        }
                      ?>

                    </tr></tbody>
                  </table>
                </div>
        </div>
        </div>
        </div>
    </div>
</div>

   
<?php require_once('footer.php'); ?>