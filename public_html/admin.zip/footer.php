
</div>
<div class="copyrite">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <div class="social-icon"> <a href="#"><img src="images/facebook.png" alt="Facebook"></a> <a href="#"><img src="images/googleplus.png" alt="Google Plus"></a> <a href="#"><img src="images/twitter.png" alt="Twitter"></a> <a href="#"><img src="images/rss.png" alt="RSS"></a> </div>
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="text">&copy; 2015 BOOKUP. ALL RIGHTS RESERVED.</div>
        </div>
      </div>
    </div>
  </div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.ui.touch-punch.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script src="js/bookup_1.js"></script>
<script src="js/jquery.validate.min.js"></script>
</body>
</html>