<?php 
require_once('admin/includes/configurations.php');
$body_id = 'aboutusbody';
require_once('header.php'); 
?>
<div class="white_bg">
	<div class="container">
    	<div class="cms">
        	<h1>BOOKUP STORY</h1>
            <p>Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
            
            <p>Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like) Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
            
            <p>Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.</p>
            
        </div>
    </div>
</div>

  <div class="tellus">
    <div class="container">
      <div class="tellusbg">
        <div class="row">
          <div class="col-md-9 col-sm-8">
            <h2>Tell us what features you want</h2>
            <p>Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, making it look like readable </p>
          </div>
          <div class="col-md-3 col-sm-4">
            <div class="readmore-1"><a href="#">Click here</a></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--
  <div class="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-4">
          <div class="logo"><a href="#"><img src="images/footer-logo.png" alt="" ></a></div>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae. Sed dui lorem, adipiscing in adipiscing et, interdum nec .</p>
          <div class="address">
            <div class="col-group">
              <label>Phone:</label>
              <span>000-2000-000</span> </div>
            <div class="col-group">
              <label>e-mail:</label>
              <span><a href="mailto:info@solutionswithus.com">info@solutionswithus.com</a></span> </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-3">
          <h2>Navigation</h2>
          <ul>
            <li><a href="#" class="active" title="Home">Home</a></li>
            <li><a href="#" title="About Us">About Us</a></li>
            <li><a href="#" title="Contact Us">Contact Us</a></li>
            <li><a href="#" title="Login">Login</a></li>
            <li><a href="#" title="Register">Register</a></li>
          </ul>
        </div>
        <div class="col-md-5 col-sm-5">
          <h2>Contact Us</h2>
          <div class="contact-form">
            <div class="form-group">
              <div class="col-md-6 col-sm-6">
                <input type="text" value="" placeholder="Full Name">
              </div>
              <div class="col-md-6 col-sm-6">
                <input type="text" value="" placeholder="Email Address">
              </div>
            </div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12">
                <textarea name="" cols="" rows=""></textarea>
              </div>
            </div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12">
                <input type="button" value="Submit">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  -->
<?php require_once('footer.php'); ?>