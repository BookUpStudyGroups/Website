<?php
require_once('admin/includes/configurations.php');
$body_id = 'registerbody';
require_once('logincheck.php');

require_once('admin/module/classLecturer.php');
require_once('admin/module/classManageClass.php');
require_once('admin/module/classStudent.php');
require_once('admin/module/classStudentCourse.php');

$lecturers_result = $LecturerObj->getAllActiveLecturer('');
$classes_result = $ManageClassObj->getAllActiveClass('');

$errors = array();
$successMsg = "";
$fields = array();

if( isset( $_POST['reg_submit'] ) ){		

  $rules  = array(); 

  $rules[]  = "required,fname,Please enter first name.";
  $rules[]  = "required,lname,Please enter last name.";
  $rules[]  = "required,email,Please enter email address.";
  $rules[]  = "valid_email,email,Please enter valide email address.";
  $rules[]  = "required,password,Please enter password.";
  $rules[]  = "required,gender,Please select gender.";
  $rules[]  = "required,class_year,Please enter class year.";
  $rules[]  = "required,term,Please select term.";
  
  $errors   = validateFields($_POST, $rules);

  if (!empty($errors)){  
    $fields = $_POST;  
  }else{
    
    if($StudentObj->getStudentByEmail( $CommanObj->inscrape($_POST['email']))){
      $errors[]   =  "This email address has been already registered.";     
      $fields = $_POST;  
    }else{
        if( isset( $_FILES['profile_pic'] )){
          $file = $_FILES['profile_pic'];
          $file_name = $file['name'];
          $file_size = $file['size'];
          $tmp_name = $file['tmp_name'];
          $new_pic_name = time() . $file_name;

          $target = PP_UPLOAD_PATH . $new_pic_name;

          if( move_uploaded_file( $tmp_name, $target ) )
          {
            $profile_pic =  $new_pic_name;
          }
        }//profile pic set
        $StudentObj->active = 1;
        $StudentObj->fname = $CommanObj->inscrape($_POST['fname']);
        $StudentObj->mname = $CommanObj->inscrape($_POST['mname']);
        $StudentObj->lname = $CommanObj->inscrape($_POST['lname']);
        $StudentObj->email = $CommanObj->inscrape($_POST['email']);
        $StudentObj->password = $CommanObj->inscrape($_POST['password']);
        $StudentObj->profile_pic = $CommanObj->inscrape($profile_pic);

        $StudentObj->gender = $CommanObj->inscrape($_POST['gender']);
        $StudentObj->class_year = $CommanObj->inscrape($_POST['class_year']);
        $StudentObj->class_name_custom = $CommanObj->inscrape($_POST['class_name_custom']);
        $StudentObj->term = $CommanObj->inscrape($_POST['term']);
        $StudentId = $StudentObj->insertStudent();
        if($StudentId != 0){
          
          $CourseArray = array();

          for( $i = 0; $i < count( $_POST['course_number'] ); $i++ ){
            $course_num = $_POST['course_number'][$i];
            $lecturer_id = $_POST['course_professor'][$i];
            $department_id = $_POST['course_department'][$i];
            $StudentCourseObj->course_num = $CommanObj->inscrape($course_num);
            $StudentCourseObj->lecturer_id = $CommanObj->inscrape($lecturer_id);
            $StudentCourseObj->department_id = $CommanObj->inscrape($department_id);
            $StudentCourseObj->user_id = $CommanObj->inscrape($StudentId);
            $StudentCourseObj->insertStudentCourse();
            
          }
          $successMsg = "Successfully registered.";
          $_POST = array();
			$studentRecord = $StudentObj->getStudentById($StudentId);
			if($studentRecord){
				$_SESSION['student_user'] = $studentRecord;
				header("location:profile.php?msg=successRegistered");
				exit;
			}
        }else{
          $errors[]   =  "There is some error in processing your request.";     
          $fields = $_POST; 
        }
        
    }

  }
        
}//submit check

?>
<?php require_once('header.php'); ?>
  <div class="white_bg padding-page">
    <div class="container">
      <div class="col-xs-12 col-md-6 col-sm-7 col-centered">
      	<?php
          if( isset($errors) && count($errors) >0 ){
            foreach($errors as $key=>$val){
        ?>
            <p class="error_msg"><?php echo $val;?></p>
        <?php
            }
          }
       ?>
        <?php
          if( isset($successMsg) && $successMsg !="" ){
				?>
            <p class="success_msg">Your account has been resgistered successfully. Please <a href="login.php">Log in</a>.</p>
        <?php
				  }
			 ?>
      
		<div class="reg-title">Register your BookUp account</div>
        <div class="login_box registration">
          <form method="post" action="" id="registerform" enctype="multipart/form-data" onSubmit="return valideRegistrationform();">
            <div class="row">
              <div class="col-md-4 col-sm-4">
                <div class="form-group">
                  <label for="fname">First Name</label>
                  <input type="text" class="form-control" value="<?=(!empty($_POST['fname']))? $CommanObj->inscrape($_POST['fname']) : '';?>" placeholder="First Name" name="fname" id="fname">
                </div>
              </div>
              <div class="col-md-4 col-sm-4">
                <div class="form-group">
                  <label for="mname">Middle Name</label>
                  <input type="text" class="form-control" placeholder="Middle Name" name="mname" id="mname" value="<?=(!empty($_POST['mname']))? $CommanObj->inscrape($_POST['mname']) : '';?>">
                </div>
              </div>
              <div class="col-md-4 col-sm-4">
                <div class="form-group">
                  <label for="lname">Last Name</label>
                  <input type="text" class="form-control" placeholder="Last Name" name="lname" id="lname" value="<?=(!empty($_POST['lname']))? $CommanObj->inscrape($_POST['lname']) : '';?>">
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="email">Email Address</label>
              <input type="email" class="form-control" placeholder="Email Address" name="email" id="email" value="<?=(!empty($_POST['email']))? $CommanObj->inscrape($_POST['email']) : '';?>">
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" placeholder="Password" name="password" id="password">
            </div>
            <div class="form-group">
              <label for="cpassword">Confirm Password</label>
              <input type="password" class="form-control" placeholder="Confirm Password" name="cpassword" id="cpassword">
            </div>
            <div class="form-group upload">
              <label for="profile_pic">Profile Image</label>
              <input type="file" class="form-control" name="profile_pic" id="profile_pic">
            </div>
            <div class="form-group">
              <label for="gender_m">Gender</label>
              <div class="gender">
              <div class="male">
              
                <input type="radio" class="form-control"  name="gender" id="gender_m" value="male" checked="checked">
                <span>Male</span>
                </div>
                <div class="female">                
                <input type="radio" class="form-control" name="gender" id="gender_f" value="female" <?=(!empty($_POST['gender']) && $_POST['gender'] == "female")? 'checked="checked"' : '';?>>
                <span>Female</span>
              </div>
              <div class="othergender">                
                <input type="radio" class="form-control" name="gender" id="gender_o" value="other" <?=(!empty($_POST['gender']) && $_POST['gender'] == "other")? 'checked="checked"' : '';?>>
                <span>Other</span>
              </div>
              </div>
            </div>
            <div class="form-group">
              <label for="class_year">Class Year</label>
              <input type="text" class="form-control" placeholder="Class Year" name="class_year" id="class_year" value="<?=(!empty($_POST['class_year']))? $CommanObj->inscrape($_POST['class_year']) : '';?>">
            </div>
            <div class="form-group">
              <label for="term">Term</label>
              <select class="form-control" name="term" id="term">
                <option value="Fall" <?=(!empty($_POST['term']) && $_POST['term'] == "Fall")? 'selected="selected"' : '';?>>Fall</option>
                <option value="Winter" <?=(!empty($_POST['term']) && $_POST['term'] == "Winter")? 'selected="selected"' : '';?>>Winter</option>
                <option value="Spring" <?=(!empty($_POST['term']) && $_POST['term'] == "Spring")? 'selected="selected"' : '';?>>Spring</option>
                <option value="Summer" <?=(!empty($_POST['term']) && $_POST['term'] == "Summer")? 'selected="selected"' : '';?>>Summer</option>
              </select>
            </div>
            <div class="form-group">
              <label for="">Currently Registered Courses</label>
			  <?php 
				if(isset($_POST['course_department'])){
					foreach($_POST['course_department'] as $key=>$postData){
						$cont = $key + 1;
						$lecturersResult = $LecturerObj->getAllActiveLecturer();
						$classesResult = $ManageClassObj->getAllActiveClass();
					?>
						<div class="classesrow" id="classesrow<?php echo $cont; ?>">
							<div class="row">
							<div class="col-md-4 col-sm-4">
							  <select class="form-control" name="course_department[]">
								<option value="">Department Name</option>
								<?php
									while( $department = mysql_fetch_array( $classesResult ) ){
									?>
									
									   <option value="<?php echo $department['classID']; ?>" <?php echo (!empty($_POST["course_department"][$key]) && $_POST["course_department"][$key] == $department['classID']) ? "selected='selected'" : ""; ?>><?php echo $department['name']; ?></option>
								  <?php
								  }//while
								?>
							  </select>
							</div>
							<div class="col-md-4 col-sm-4">
							  <select class="form-control" name="course_number[]">
								<option value="">Course Number</option>
								<?php
									for( $i = 1; $i <= 99; $i++ )
									{
										if( $i < 10 )	
										{
											$c_num = '0'.$i;
											?>
											<option value="<?php echo $c_num; ?>" <?php echo (!empty($_POST["course_number"][$key]) && $_POST["course_number"][$key] == $c_num) ? "selected='selected'" : ""; ?>><?php echo $c_num; ?></option>
											<?php
										}
										else
										{
											?>
											<option value="<?php echo $i; ?>" <?php echo (!empty($_POST["course_number"][$key]) && $_POST["course_number"][$key] == $i) ? "selected='selected'" : ""; ?>><?php echo $i; ?></option>
											<?php
										}
									}
								?>
							  </select>
							</div>
							<div class="col-md-4 col-sm-4">
							  <select class="form-control" name="course_professor[]">
								<option value="">Professor's Last Name</option>
								<?php

									while( $lecturer = mysql_fetch_array( $lecturersResult ) )
									{
										?>
										<option value="<?php echo $lecturer['lecturerID']; ?>" <?php echo (!empty($_POST["course_professor"][$key]) && $_POST["course_professor"][$key] == $lecturer['lecturerID']) ? "selected='selected'" : ""; ?>><?php echo $lecturer['lastName']; ?></option>
										<?php
									}//while
								?>
							  </select>
							</div>
							</div>
						  </div><!--.classesrow-->
			  <?php
					}
				}else{
			  ?>
              <div class="classesrow" id="classesrow1">
				<div class="row">
                <div class="col-md-4 col-sm-4">
                  <select class="form-control" name="course_department[]">
                    <option value="">Department Name</option>
                    <?php
                    	while( $department = mysql_fetch_array( $classes_result ) ){
						?>
						
						   <option value="<?php echo $department['classID']; ?>" <?php echo (!empty($_POST["course_department"][0]) && $_POST["course_department"][0] == $department['classID']) ? "selected='selected'" : ""; ?>><?php echo $department['name']; ?></option>
					  <?php
					  }//while
					?>
                  </select>
                </div>
                <div class="col-md-4 col-sm-4">
                  <select class="form-control" name="course_number[]">
                    <option value="">Course Number</option>
                    <?php
                    	for( $i = 1; $i <= 99; $i++ )
						{
							if( $i < 10 )	
							{
								$c_num = '0'.$i;
								?>
								<option value="<?php echo $c_num; ?>" <?php echo (!empty($_POST["course_number"][0]) && $_POST["course_number"][0] == $c_num) ? "selected='selected'" : ""; ?>><?php echo $c_num; ?></option>
								<?php
							}
							else
							{
								?>
								<option value="<?php echo $i; ?>" <?php echo (!empty($_POST["course_number"][0]) && $_POST["course_number"][0] == $i) ? "selected='selected'" : ""; ?>><?php echo $i; ?></option>
								<?php
							}
						}
					?>
                  </select>
                </div>
                <div class="col-md-4 col-sm-4">
                  <select class="form-control" name="course_professor[]">
                    <option value="">Professor's Last Name</option>
                    <?php

                    	while( $lecturer = mysql_fetch_array( $lecturers_result ) )
						{
							?>
							<option value="<?php echo $lecturer['lecturerID']; ?>" <?php echo (!empty($_POST["course_professor"][0]) && $_POST["course_professor"][0] == $lecturer['lecturerID']) ? "selected='selected'" : ""; ?>><?php echo $lecturer['lastName']; ?></option>
							<?php
						}//while
					?>
                  </select>
                </div>
				</div>
              </div><!--.classesrow-->
			  <?php } ?>
              <div class="form-group">
                    <a class="btn btn-info" id="add-course-row">Add Course</a>
                    <a class="btn btn-warning" id="remove-course-row">Remove Course</a>
              </div>
            </div>
			<div class="form-group">
				  <label for="class_year">Don't see your class? Request we add it below!</label>
				  <input type="text" class="form-control" placeholder="Request class" name="class_name_custom" id="class_name_custom" value="<?=(!empty($_POST['class_name_custom']))? $CommanObj->inscrape($_POST['class_name_custom']) : '';?>">
				</div>
            <div class="form-group term">
              <!-- <input type="checkbox" class="form-control" placeholder="Email Address"> -->
              <label>By clicking BookUp, you have read and agree to our <a href="terms-and-conditions.php" title="Terms and Conditions"><b>Terms and Conditions</b>.</a></label>
            </div>
            <div class="submit">
              <button class="btn btn-default" title="BookUp" type="reg_submit" name="reg_submit" id="submit">BookUp</button>
            </div>
          </form>
          <div class="create_account"><a target="_blank" href="#"></a></div>
        </div>
      </div>
    </div>
  </div>
<?php require_once('footer.php'); ?>