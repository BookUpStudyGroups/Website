<?php
require_once('admin/includes/configurations.php');
$body_id = 'editprofilebody';
require_once('logincheck.php');

require_once('admin/module/classLecturer.php');
require_once('admin/module/classManageClass.php');
require_once('admin/module/classStudent.php');
require_once('admin/module/classStudentCourse.php');

$lecturers_result = $LecturerObj->getAllActiveLecturer('');
$classes_result = $ManageClassObj->getAllActiveClass('');
$studentData = $StudentObj->getStudentById($_SESSION['student_user']['id']);

$student_courses = $StudentCourseObj->getAllCoursesById( $_SESSION['student_user']['id']);

$errors = array();
$successMsg = "";
$fields = array();

if( isset( $_POST['reg_submit'] ) ){		

  $rules  = array(); 
  $rules[]  = "required,term,Please select term.";
  
  $errors   = validateFields($_POST, $rules);

  if (!empty($errors)){  
		$fields = $_POST;  
  }else{
        if( isset( $_FILES['profile_pic']['name'] ) && $_FILES['profile_pic']['name'] != ''){
          $file = $_FILES['profile_pic'];
          $file_name = $file['name'];
          $file_size = $file['size'];
          $tmp_name = $file['tmp_name'];
          $new_pic_name = time() . $file_name;

          $target = PP_UPLOAD_PATH . $new_pic_name;

          if( move_uploaded_file( $tmp_name, $target ) )
          {
            $profile_pic =  $new_pic_name;
          }
        }//profile pic set
		else{
			$profile_pic = $_POST['eidtpic'];
			
		}
       
        $StudentObj->profile_pic = $CommanObj->inscrape($profile_pic);
        $StudentObj->term = $CommanObj->inscrape($_POST['term']);
        $StudentObj->class_name_custom = $CommanObj->inscrape($_POST['class_name_custom']);
        $StudentId = $StudentObj->updateStudentNormal($_SESSION['student_user']['id']);
		
		$postID = implode(',', $_POST['updateID']);
		$sql = "SELECT * FROM ".tblUserCourse." WHERE id NOT IN (".$postID.") AND user_id='".$_SESSION['student_user']['id']."'";
		$result = mysql_query($sql);
		$numRows = mysql_num_rows($result);
		if($numRows > 0){
			while($data = mysql_fetch_assoc($result)){
				mysql_query("DELETE FROM ".tblUserCourse." WHERE id='".$data['id']."'");
			}
		}

          for( $i = 0; $i < count( $_POST['course_number'] ); $i++ ){
            $course_num = $_POST['course_number'][$i];
            $lecturer_id = $_POST['course_professor'][$i];
            $department_id = $_POST['course_department'][$i];
            $StudentCourseObj->course_num = $CommanObj->inscrape($course_num);
            $StudentCourseObj->lecturer_id = $CommanObj->inscrape($lecturer_id);
            $StudentCourseObj->department_id = $CommanObj->inscrape($department_id);
            $StudentCourseObj->user_id = $_SESSION['student_user']['id'];
			
			if(isset($_POST['lecturerEditField'][$i]) && $_POST['lecturerEditField'][$i] != ''){
				$StudentCourseObj->updateStudentCourse($_POST['updateID'][$i]);
			}else{
				$StudentCourseObj->insertStudentCourse();
			}
            
          }
		  
         exit("<script>window.location='editprofile.php?mes=updateProfile';</script>");
          $_POST = array();
          
        }
        
}//submit check

?>
<?php require_once('header.php'); ?>
  <div class="white_bg padding-page">
    <div class="container">
      <div class="col-xs-12 col-md-6 col-sm-7 col-centered">
      	<?php
          if( isset($errors) && count($errors) >0 ){
            foreach($errors as $key=>$val){
        ?>
            <p class="error_msg"><?php echo $val;?></p>
        <?php
            }
          }
       ?>
        <?php
          if( isset($successMsg) && $successMsg !="" ){
				?>
            <p class="success_msg">Your account has been updated successfully.</p>
        <?php
				  }
			 ?>
			 
		<?php
          if( isset($_GET['mes']) && $_GET['mes'] =="updateProfile" ){
				?>
            <p class="success_msg">Your account has been updated successfully.</p>
        <?php
				  }
			 ?>
      
		<div class="reg-title">Edit Profile</div>
        <div class="login_box registration">
          <form method="post" action="" id="registerform" enctype="multipart/form-data" >
            <div class="row">
              
            <?php
				$defaultImage = "images/default.png";
				if($studentData['profile_pic'] != ""){
				  $defaultImage = PP_UPLOAD_PATH  . $studentData['profile_pic'];      
				}
			  ?>
            <div class="form-group upload">
              <label for="profile_pic">Profile Image</label>
              <input type="file" class="form-control" name="profile_pic" id="profile_pic"> <img src="<?=$defaultImage;?>" style="width:70px; height:auto;">
            </div>
            
            <div class="form-group">
              <label for="term">Term</label>
              <select class="form-control" name="term" id="term">
                <option value="Fall">Fall</option>
                <option value="Winter" <?=((!empty($_POST['term']) && $_POST['term'] == "Winter") || $CommanObj->inscrape($studentData['term']) == 'Winter') ? 'selected="selected"' : '';?>>Winter</option>
                <option value="Spring" <?=((!empty($_POST['term']) && $_POST['term'] == "Spring") || $CommanObj->inscrape($studentData['term']) == 'Spring') ? 'selected="selected"' : '';?>>Spring</option>
                <option value="Summer" <?=((!empty($_POST['term']) && $_POST['term'] == "Summer") || $CommanObj->inscrape($studentData['term']) == 'Summer') ? 'selected="selected"' : '';?>>Summer</option>
              </select>
            </div>
            <div class="form-group" style="">
              <label for="">Currently Registered Courses</label>
              <?php
              	$x = 1;
				
				while( $row = mysql_fetch_array( $student_courses ) )
				{
					$lecturersResult = $LecturerObj->getAllActiveLecturer('');
					$classesResult = $ManageClassObj->getAllActiveClass('');
					?>
					<input name="lecturerEditField[]" type="hidden" value="<?php echo $row['lecturer_id']; ?>">
					<input name="courseEditField[]" type="hidden" value="<?php echo $row['course_num']; ?>">
					<input name="departmentEditField[]" type="hidden" value="<?php echo $row['department_id']; ?>">
					
					<div class="classesrow" id="classesrow<?php echo $x; ?>">
					<input name="updateID[]" type="hidden" value="<?php echo $row['id']; ?>">
					<div class="row">
					<div class="col-md-4 col-sm-4">
					  <select class="form-control" name="course_department[]">
						<option value="">Department Name</option>
						<?php
							while( $department = mysql_fetch_array( $classesResult ) ){
									if( $department['classID'] == $row['department_id'] )
									{
										   echo '<option value="'.$department['classID'].'" selected="selected">'.$department['name'].'</option>';
									}
									else
									{
										   echo '<option value="'.$department['classID'].'">'.$department['name'].'</option>';	
									}
									  }//while
						?>
					  </select>
					</div>
					<div class="col-md-4 col-sm-4">
					  <select class="form-control" name="course_number[]">
						<option value="">Course Number</option>
						<?php
							for( $i = 1; $i <= 99; $i++ )
							{
								if( $i < 10 )	
								{
									$c_num = '0'.$i;
									if( $row['course_num'] == $c_num )
										echo '<option value="'.$c_num.'" selected="selected">'.$c_num.'</option>';
									else	
										echo '<option value="'.$c_num.'">'.$c_num.'</option>';
								}
								else
								{
									if( $row['course_num'] == $i )
										echo '<option value="'.$i.'" selected="selected">'.$i.'</option>';
									else
										echo '<option value="'.$i.'">'.$i.'</option>';
								}
							}
						?>
					  </select>
					</div>
					<div class="col-md-4 col-sm-4">
					  <select class="form-control" name="course_professor[]">
						<option value="">Professor's Last Name</option>
						<?php
							
							while( $lecturer = mysql_fetch_array( $lecturersResult ) )
							{
								
								if( $row['lecturer_id'] == $lecturer['lecturerID'] )
									echo '<option value="'.$lecturer['lecturerID'].'" selected="selected">'.$lecturer['lastName'].'</option>';
								else
									echo '<option value="'.$lecturer['lecturerID'].'">'.$lecturer['lastName'].'</option>';
							}//while
						?>
					  </select>
					</div>
					</div>
				  </div><!--.classesrow-->
                 <?php
				 $x++;
				}//while
			  ?>
              
              <div class="form-group">
                    <a class="btn btn-info" id="add-course-row">Add Course</a>
                    <a class="btn btn-warning" id="remove-course-row">Remove Course</a>
              </div>
            </div>
            <div class="form-group">
				  <label for="class_year">Don't see your class? Request we add it below!</label>
				  <input type="text" class="form-control" placeholder="Request class" name="class_name_custom" id="class_name_custom" value="<?=(!empty($_POST['class_name_custom']))? $CommanObj->inscrape($_POST['class_name_custom']) : $CommanObj->inscrape($studentData['class_name_custom']);?>">
			</div>
            <div class="submit">
			  <input type="hidden" class="form-control" name="editemail" value="<?=$CommanObj->inscrape($studentData['email']);?>">
			  <input type="hidden" class="form-control" name="eidtpic" value="<?=$CommanObj->inscrape($studentData['profile_pic']);?>">
              <button class="btn btn-default" title="BookUp" type="reg_submit" name="reg_submit" id="submit">Update</button>
            </div>
        	</div>
          </form>
          <div class="create_account"><a target="_blank" href="#"></a></div>
        </div>
      </div>
    </div>
  </div>

<?php require_once('footer.php'); ?>