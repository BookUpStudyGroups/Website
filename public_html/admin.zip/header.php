<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width">
<meta name="author" content="BookUp">
<meta name="keywords" content="BookUp">
<meta name="description" content="BookUp">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="format-detection" content="telephone=no">
<title>BookUp</title>
<link href="css/bootstrap.css" rel="stylesheet">
<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><link href="style/ie8.css" rel="stylesheet"><![endif]-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" href="css/scroll.css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
</head>
<body id="<?php echo $body_id; ?>">
<div id="wrap" class="bookup">
  <header id="header">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-4">
          <div class="logo"><a href="index.php"> <img src="images/logo-inner.png" alt="Bookup" title="Bookup"></a> </div>
        </div>
        <div class="col-md-8 col-sm-8">
          <nav id="navigation" class="pull-right">
            <div class="navbar-header"> <a href="#">Navigation</a>
              <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed" type="button"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            </div>
            <div class="navbar-collapse collapse" id="navbar">
              <ul class="nav navbar-nav">
                <li><a href="index.php" title="Home" <?php echo $body_id == 'profilebody' ? 'class="active"' : ''; ?>>Home</a></li>
                <?php if(isset( $_SESSION['student_user'] ) )
				{
					?>
                <li><a href="groups.php" title="View Group" <?php echo $body_id == 'groupbody' ? 'class="active"' : ''; ?>>View Group</a></li>
                <li><a href="search-group.php" title="Search group" <?php echo $body_id == 'search_group_body' ? 'class="active"' : ''; ?>>Search Group</a></li>
                <li><a href="logout.php" title="Log out">Log out</a></li>
                    <?php
				}
				else
				{
				?>
                <li><a href="register.php" title="Register" <?php echo $body_id == 'registerbody' ? 'class="active"' : ''; ?>>Register</a></li>
                <li><a href="login.php" title="Login" <?php echo $body_id == 'loginbody' ? 'class="active"' : ''; ?>>Login</a></li>
                <?php 
				}
				?>
                <li><a href="about-us.php" title="About Us" <?php echo $body_id == 'aboutusbody' ? 'class="active"' : ''; ?>>About Us</a></li>
                <li><a href="contact.php" title="Contact Us" <?php echo $body_id == 'contactbody' ? 'class="active"' : ''; ?>>Contact Us</a></li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </header>