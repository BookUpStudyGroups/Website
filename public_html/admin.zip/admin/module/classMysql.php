<?php
	/*******************************************************************************
	 *                         MySQL Database Class
	 *		dumpSQL($sql)
	 *		
	 *		selectSQL($sql) 
	 *		selectOneSQL($sql)
	 *		
	 *		getRow($result, $type),	getRowObj($result, $type)
	 *		getNumRow($result) 
	 *		
	 *		insertSQL($sql)
	 *		insertArraySQL($table, $data)
	 *
	 *		updateSQL($sql)
	 *		updateArraySQL($table, $data, $condition)
	 *
	 *		executeFile($file)
	 *
	 *		getColumnType($table, $column) 
	 *
	 *		sqlDateFormat($value, $type)
	 *
	 *		printLastError($show_query=true)
	 *
	 *		printLastQuery()
	 *******************************************************************************/

	// constants used by class
	define('MYSQL_TYPES_NUMERIC', 	'int real ');
	define('MYSQL_TYPES_DATE', 		'datetime timestamp year date time ');
	define('MYSQL_TYPES_STRING', 	'string blob ');
	
	class connectionMySQL  
	{	 
	   var $lastError;         // holds the last error. Usually mysqlError()
	   var $lastQuery;         // holds the last query executed.
	   
	   var $dbHostname;         // mySQL host to connect to
	   var $dbUsername;         // mySQL user name
	   var $dbPassword;         // mySQL password
	   var $dbName;             // mySQL database to select
	
	   var $dbLink;             // current/last database link identifier
	   var $autoSlashes;        // the class will add/strip slashes when it can
	   var $recordSet;
	   
	   function connectionMySQL() 
	   {
	   
		  // Setup your own default values for connecting to the database here. You
		  // can also set these values in the connectMYSQL() function and using
		  // the selectDB() function.
		  if (!$this->connect(dbHostname, dbUsername, dbPassword, dbName, false)) 
		  	$this->printLastError(false);	
	
		  $this->autoSlashes = true;
	   }

	/*
	 * Returns the query needed to get some backend info
	 * @param string $type What kind of info you want to retrieve
	 * @return string The SQL query string
	*/	
	   function connect($dbHostname, $dbUsername, $dbPassword, $dbName, $persistant=true) 
	   {
	 
		  // Opens a connection to MySQL and selects the database.  If any of the
		  // function's parameter's are set, we want to update the class variables.  
		  // If they are NOT set, then we're giong to use the currently existing
		  // class variables.
		  // Returns true if successful, false if there is failure.  
		  
		  if (!empty($dbHostname)) 	$this->dbHostname = $dbHostname; 
		  if (!empty($dbUsername)) 	$this->dbUsername = $dbUsername; 
		  if (!empty($dbPassword))	$this->dbPassword = $dbPassword; 
	 
			
		  // Establish the connection.
		  if ($persistant) 
			$this->dbLink = mysql_pconnect($this->dbHostname, $this->dbUsername, $this->dbPassword);
		  else 
			$this->dbLink = mysql_connect($this->dbHostname, $this->dbUsername, $this->dbPassword);
	 
	 
		  // Check for an error establishing a connection
		  if (!$this->dbLink) 
		  {
			 $this->lastError = mysql_error();
			 return false;
		  } 
		  
	  
		  // Select the database
		  if (!$this->selectDB($dbName)) 
		  	return false;
	 
		  return true;  // success
	   }
	
	   function selectDB($dbName) 
	   {
	 		
		  // Selects the database for use.  If the function's $dbName parameter is 
		  // passed to the function then the class variable will be updated.
	 
		  if (!empty($dbName)) $this->$dbName = $dbName; 
		  
		  
		  if (!mysql_select_db($this->$dbName)) 
		  {
			 $this->lastError = mysql_error();
			 return false;
		  }
	 
		  return true;
	   }
	   
	   function selectSQL($sql) 
	   {
		  
		  // Performs an SQL query and returns the result pointer or false
		  // if there is an error.
	 
		  $this->lastQuery = $sql;
		    
		  $r = mysql_query($sql);
		  $this->recordSet = $r;
		 
		  if (!$r) {
			 $this->lastError = mysql_error();
			 return false;
		  }
		  return $r;
	   }
	
	   function selectOneSQL($sql) 
	   {
	 
		  // Performs an SQL query with the assumption that only ONE column and
		  // one result are to be returned.
		  // Returns the one result.
	 
		  $this->lastQuery = $sql;
		  
		  
		  $r = mysql_query($sql);
		  $this->recordSet = $r;
		  
		  if (!$r) 
		  {
			 $this->lastError = mysql_error();
			 return false;
		  }
		  
		  if (mysql_num_rows($r) > 1) 
		  {
			 $this->lastError = "Your query in function SelectOneSQL() returned more that one result.";
			 return false;     
		  }
		  
		  $ret = mysql_result($r, 0);
		  mysql_free_result($r);
		  
		  if ($this->autoSlashes) return stripslashes($ret);		  
		  else return $ret;
	   }

	   function getRow($type='MYSQL_ASSOC') 
	   {
	 
		  // Returns a row of data from the query result.  You would use this
		  // function in place of something like while($row = mysql_fetch_array($r)). 
		  // Instead you would have while($row = $Obj->get_row()) The
		  // main reason you would want to use this instead is to utilize the
		  // autoSlashes feature.
		  
		  if ($type == 'MYSQL_ASSOC') 	$row = mysql_fetch_array($this->recordSet, MYSQL_ASSOC);
		  if ($type == 'MYSQL_NUM') 	$row = mysql_fetch_array($this->recordSet, MYSQL_NUM);
		  if ($type == 'MYSQL_BOTH') 	$row = mysql_fetch_array($this->recordSet, MYSQL_BOTH); 
		  
		  if (!$row) return false;
		  
		  if ($this->autoSlashes) 
		  {
			 // strip all slashes out of row...
			 foreach ($row as $key => $value) 
			 {
				$row[$key] = stripslashes($value);
			 }
		  }
		  
		  return $row;
	   }

	   function getNumRow() 
	   {
	 
		  // Returns a no of row data from the query result.  You would use this
		  // function in place of something like while($row = mysql_num_rows($r)). 
		  // Instead you would have $row = $Obj->GetNumRow(); 
		  $row = mysql_num_rows($this->recordSet); 
		  
		  return $row;
	   }

	   function dumpSQL($sql) 
	   {
	   
		  // Useful during development for debugging  purposes.  Simple dumps a 
		  // query to the screen in a table.
	 
		  $r = $this->selectSQL($sql);
		  if (!$r) return false;
		  
		  echo "<div style=\"border: 1px solid blue; font-family: sans-serif; margin: 8px;\">\n";
		  echo "<table cellpadding=\"3\" cellspacing=\"1\" border=\"0\" width=\"100%\">\n";
		  
		  $i = 0;
		  while ($row = mysql_fetch_assoc($r)) 
		  {
			 if ($i == 0) 
			 {
				echo "<tr><td colspan=\"".sizeof($row)."\"><span style=\"font-face: monospace; font-size: 9pt;\">$sql</span></td></tr>\n";
				echo "<tr>\n";
				foreach ($row as $col => $value) 
				{
				   echo "<td bgcolor=\"#E6E5FF\"><span style=\"font-face: sans-serif; font-size: 9pt; font-weight: bold;\">$col</span></td>\n";
				}
				echo "</tr>\n";
			 }
			 $i++;
			 if ($i % 2 == 0) $bg = '#E3E3E3';
			 else $bg = '#F3F3F3';
			 
			 echo "<tr>\n";
			 foreach ($row as $value) 
			 {
				echo "<td bgcolor=\"$bg\"><span style=\"font-face: sans-serif; font-size: 9pt;\">$value</span></td>\n";
			 }
			 echo "</tr>\n";
		  }
		  echo "</table></div>\n";
	   }
	   
	   function insertSQL($sql) 
	   {
		   
		  // Inserts data in the database via SQL query.
		  // Returns the id of the insert or true if there is not auto_increment
		  // column in the table. Returns false if there is an error.      
	 
		  $this->lastQuery = $sql;
		  
		  $r = mysql_query($sql);
		  if (!$r) 
		  {
			 $this->lastError = mysql_error();
			 return false;
		  }
		  
		  $id = mysql_insert_id();
		  
		  if ($id == 0) return true;	  
		  else return $id; 
	   }
	
	   function updateSQL($sql) 
	   {
	 
		  // Updates data in the database via SQL query.
		  // Returns the number or row affected or true if no rows needed the update.
		  // Returns false if there is an error.
	
		  $this->lastQuery = $sql;
		  
		  $r = mysql_query($sql);
		  if (!$r) 
		  {
			 $this->lastError = mysql_error();
			 return false;
		  }
		  
		  $rows = mysql_affected_rows();
		  
		  if ($rows == 0) return true;  // no rows were updated	  
		  else return $rows;
	   }
	   
	   function insertArraySQL($table, $data) 
	   {
		  
		  // Inserts a row into the database from key->value pairs in an array. The
		  // array passed in $data must have keys for the table's columns. You can
		  // not use any MySQL functions with string and date types with this 
		  // function.  You must use insert_sql for that purpose.
		  // Returns the id of the insert or true if there is not auto_increment
		  // column in the table.  Returns false if there is an error.
		  
		  if (empty($data)) 
		  {
			 $this->lastError = "You must pass an array to the insertArraySQL() function.";
			 return false;
		  }
		  
		  $cols 	= '(';
		  $values 	= '(';
		  
		  foreach ($data as $key=>$value) 
		  {     											// iterate values to input
			  
			 $cols .= "$key,";  
			 
			 $colType = $this->getColumnType($table, $key); // get column type
			 if (!$colType) return false;  					// error!
			 
			 // determine if we need to encase the value in single quotes
			 if (substr_count(MYSQL_TYPES_NUMERIC, "$colType ")) $values .= "$value,";
			 
			 elseif (substr_count(MYSQL_TYPES_DATE, "$colType ")) 
			 {
				$value	= $this->sqlDateFormat($value, $colType); // format date
				$values	.= "'$value',";
			 }
			 elseif (substr_count(MYSQL_TYPES_STRING, "$colType ")) 
			 {
				if ($this->autoSlashes) $value = addslashes($value);
				$values .= "'$value',";  
			 }
		  }
		  $cols 	= rtrim($cols, ',').')';
		  $values 	= rtrim($values, ',').')';     
		  
		  // insert values
		  $sql = "INSERT INTO $table $cols VALUES $values";
		  return $this->insertSQL($sql);
	   }
	   
	   function updateArraySQL($table, $data, $condition) 
	   {
		  
		  // Updates a row into the database from key->value pairs in an array. The
		  // array passed in $data must have keys for the table's columns. You can
		  // not use any MySQL functions with string and date types with this 
		  // function.  You must use insert_sql for that purpose.
		  // $condition is basically a WHERE claus (without the WHERE). For example,
		  // "column=value AND column2='another value'" would be a condition.
		  // Returns the number or row affected or true if no rows needed the update.
		  // Returns false if there is an error.
		  
		  if (empty($data)) 
		  {
			 $this->lastError = "You must pass an array to the updateArraySQL() function.";
			 return false;
		  }
		  
		  $sql = "UPDATE $table SET";
		  foreach ($data as $key=>$value) 
		  {     											// iterate values to input
			  
			 $sql .= " $key=";  
			 
			 $colType = $this->GetColumnType($table, $key); // get column type
			 if (!$colType) return false;  					// error!
			 
			 // determine if we need to encase the value in single quotes
			 if (substr_count(MYSQL_TYPES_NUMERIC, "$colType ")) $sql .= "$value,";
			 
			 elseif (substr_count(MYSQL_TYPES_DATE, "$colType ")) 
			 {
				$value 	= $this->sqlDateFormat($value, $colType); // format date
				$sql 	.= "'$value',";
			 }
			 elseif (substr_count(MYSQL_TYPES_STRING, "$colType ")) 
			 {
				if ($this->autoSlashes) $value = addslashes($value);
				$values .= "'$value',";  
			 }
	
		  }
		  $sql = rtrim($sql, ','); 									// strip off last "extra" comma
		  if (!empty($condition)) $sql .= " WHERE $condition";
		  
		  // insert values
		  return $this->updateSQL($sql);
	   }
	   
	   function executeFile ($file)
	   {
	 
		  // executes the SQL commands from an external file.
		  
		  if (!file_exists($file)) 
		  {
			 $this->lastError = "The file $file does not exist.";
			 return false;
		  }
		  
		  $str = file_get_contents($file);
		  if (!$str) 
		  {
			 $this->lastError = "Unable to read the contents of $file.";
			 return false; 
		  }
		  
		  $this->lastQuery = $str; 
		  
		  // split all the query's into an array
		  $sql = explode(';', $str);
		  foreach ($sql as $query) 
		  {
			 if (!empty($query)) 
			 {
				$r = mysql_query($query);
	 
				if (!$r) 
				{
				   $this->lastError = mysql_error();
				   return false;
				}
			 }
		  }
		  return true;
		
	   }
	   
	   function getColumnType($table, $column) 
	   {
		  
		  // Gets information about a particular column using the mysql_fetch_field
		  // function.  Returns an array with the field info or false if there is
		  // an error.
	 
		  $r = mysql_query("SELECT $column FROM $table LIMIT 1");
		  if (!$r) 
		  {
			 $this->lastError = mysql_error();
			 return false;
		  }
		  
		  $ret = mysql_field_type($r, 0);
		  
		  if (!$ret) 
		  {
			 $this->lastError = "Unable to get column information on $table.$column.";
			 mysql_free_result($r);
			 return false;
		  }
		  mysql_free_result($r);
		  return $ret;
		  
	   }
	   
	   function sqlDateFormat($value, $type) 
	   {
	
		  // Returns the date in a format for input into the database.  You can pass
		  // this function a timestamp value such as time() or a string value
		  // such as '04/14/2003 5:13 AM'. 
		  
		  if (gettype($value) == 'string') $value = strtotime($value);
		  return date('Y-m-d H:i:s', $value);
	
	   }
	   
	   function printLastError($showQuery=true) 
	   {
		  
		  // Prints the last error to the screen in a nicely formatted error message.
		  // If $show_query is true, then the last query that was executed will
		  // be displayed aswell.
	 
		  ?>
		  <div style="border: 1px solid red; font-size: 9pt; font-family: monospace; color: red; padding: .5em; margin: 8px; background-color: #FFE2E2">
			 <span style="font-weight: bold">Error:</span><br><?= $this->lastError ?>
		  </div>
		  <?php
		  if ($showQuery && (!empty($this->lastQuery))) 
		  {
		  	$this->printLastQuery();			
		  }		  				 
	   }
	
	   function printLastQuery() 
	   {
		
		  // Prints the last query that was executed to the screen in a nicely formatted
		  // box.
		 
		  ?>
		  <div style="border: 1px solid blue; font-size: 9pt; font-family: monospace; color: blue; padding: .5em; margin: 8px; background-color: #E6E5FF">
			 <span style="font-weight: bold">Last SQL Query:</span><br><?= str_replace("\n", '<br>', $this->lastQuery) ?>
		  </div>
		  <?php   
	   }
	};
?>
	 