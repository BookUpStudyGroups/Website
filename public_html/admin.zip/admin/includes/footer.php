	
	<script src="<?=$baseURL?>/js/jquery.min.js" type="text/javascript"></script>

	<link rel="stylesheet" href="<?=$baseURL?>/css/jquery-ui.css">
	
	<script src="<?=$baseURL?>/js/jquery-ui.js"></script>
	
	<script src="<?=$baseURL?>/js/bootstrap.min.js" type="text/javascript"></script>
	
	<script src="<?=$baseURL?>/js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>

	<script src="<?=$baseURL?>/js/plugins/chart.js" type="text/javascript"></script>

	<!-- datepicker
	<script src="js/plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>-->
	<!-- Bootstrap WYSIHTML5
	<script src="js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>-->
	<!-- iCheck -->
	
	<script src="<?=$baseURL?>/js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
	
	<script src="<?=$baseURL?>/js/plugins/fullcalendar/fullcalendar.js" type="text/javascript"></script>
	<!-- Director App -->
	<script src="<?=$baseURL?>/js/Director/app.js" type="text/javascript"></script>
	
	<script src="<?=$baseURL?>/js/jquery.validate.js" type="text/javascript"></script>

	<script src="<?=$baseURL?>/js/validation_message.js" type="text/javascript"></script>
	
	<!-- <div class="form-group"><label class="col-sm-4 col-sm-4 control-label"><a href="#" class="remove_field" title="remove" style="margin-left:20px;">Remove</a></label></div> -->
	</body>
	
</html>